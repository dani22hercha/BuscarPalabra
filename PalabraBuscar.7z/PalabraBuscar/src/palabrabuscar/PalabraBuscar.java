/*
Entrada cadena de carácteres
Palabra a buscar
1. Existe completa      -> TQCASAPRNO
2. Existe en orden      -> TCQAPSRNAO
3. Existe reverso       -> TAQSPARNCO
4. No existe        -> TMQSPURNBO
5. Ningún otro caso
*/
package palabrabuscar;
import java.util.Scanner;
public class PalabraBuscar {
    static Scanner texto = new Scanner (System.in);

    public static void main(String[] args) {
        String p, t;
        char l, x;
        String []pa = null;
        String p1="";
        
        System.out.println("Ingrese una palabra a buscar: ");
        p= texto.next();
        
        System.out.println("Ingrese el texto: ");
        t= texto.next();
        
        p=p.toLowerCase();
        t=t.toLowerCase();

        //------------- 1. Existe completa TQCASAPRNO-------------
        if(t.contains(p)){
            System.out.println("1.");
        }
        
        //------------- 2. Existe en orden TCQAPSRNAO-------------------
        p1="";
        //Recorre el texto
        for(int i=0; i<t.length(); i++){
            l= t.charAt(i);
            //Recorre la palabra
            for(int j=0; j<p.length(); j++){
                x= p.charAt(j);
                //Si la letra de la palabra coincide con la del texto,
                //se acumula en una palabra
                if(x==l){
                    p1+= x;
                }
            }
        }
        
        //Elimina las letras repetidas
        p1 = p1.replaceAll("(.)\\1", "$1");
        //La compara con la original
        //System.out.println("palabra: "+p1);
        if(p1.equals(p)){
            System.out.println("2.");
        }
        
        
        //-------------Existe reverso TAQSPARNCO-------------
        p1="";     
        for(int i=t.length()-1; i>=0; i--){
            l= t.charAt(i);

            //Recorre la palabra
            for(int j=p.length()-1; j>=0; j--){
                x= p.charAt(j);
                //Si la letra de la palabra coincide con la del texto,
                //se acumula en una palabra
                if(x==l){
                    p1+= x;
                }
            }
        }
        
                        
        //Elimina las letras repetidas
        p1 = p1.replaceAll("(.)\\1", "$1");
        //La compara con la original
        //System.out.println("pal:"+r);
        
        if(p1.equals(p)){
           System.out.println("3.");
        }
        
        
        //------------- 4. No existe TMQSPURNBO-------------
        p1="";
        //Recorre el texto
        for(int i=0; i<t.length(); i++){
            l= t.charAt(i);
            //Recorre la palabra
            for(int j=0; j<p.length(); j++){
                x= p.charAt(j);
                //Si la letra de la palabra coincide con la del texto,
                //se acumula en una palabra
                if(x==l){
                    p1+= x;
                }
            }
        }
        
        //Elimina las letras repetidas
        p1 = p1.replaceAll("(.)\\1", "$1");
        //La compara con la original
        //System.out.println("palabra: "+p1);
        if(!p1.equals(p)){
            System.out.println("4.");
        }
        
    }
    
}
